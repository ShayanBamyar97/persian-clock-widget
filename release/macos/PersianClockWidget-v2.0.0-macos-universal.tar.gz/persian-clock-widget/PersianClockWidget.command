#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 is not installed. Install with: brew install python python-tk"
    exit 1
fi

if ! python3 -c "import tkinter" 2>/dev/null; then
    echo "Tkinter is not installed. Install with: brew install python-tk"
    exit 1
fi

nohup python3 main.py >/dev/null 2>&1 &
echo "Persian Clock & Calendar launched!"
