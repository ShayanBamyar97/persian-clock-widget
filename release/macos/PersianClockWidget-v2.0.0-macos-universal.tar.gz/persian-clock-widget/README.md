<div dir="rtl" align="center">

<img src="assets/icons/app_icon.png" alt="Persian Clock & Calendar Widget Icon" width="128" height="128" />

# ویجت حرفه‌ای ساعت تهران، تقویم شمسی و سیستم یادآور ویندوز
### **Persian Clock, Jalali Calendar & Smart Alarm Desktop Widget**

[![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-0078D6?style=for-the-badge)](#)
[![Version](https://img.shields.io/badge/Version-2.0.0-7C3AED?style=for-the-badge)](https://github.com/ShayanBamyar97/persian-clock-widget/releases/tag/v2.0.0)
[![npm](https://img.shields.io/npm/v/persian-clock-widget?style=for-the-badge&logo=npm&color=CB3837)](https://www.npmjs.com/package/persian-clock-widget)
[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](#)
[![MCP](https://img.shields.io/badge/AI%20Ready-MCP%20%26%20REST%20API-10B981?style=for-the-badge)](#)
[![License](https://img.shields.io/badge/License-MIT-F59E0B?style=for-the-badge)](LICENSE)
[![Author](https://img.shields.io/badge/Author-%C2%AE%20Shayan%20Bamyar-38BDF8?style=for-the-badge)](#)

**یک ویجت دسکتاپ فوق‌سبک، مینیمال، کاملاً آفلاین و قابل شخصی‌سازی برای ویندوز**  
شامل ساعت دقیق به وقت تهران، تاریخ هجری شمسی، مناسبت‌ها و تعطیلات رسمی، تقویم ماهانه بازشونده، سیستم آلارم با ۶ صدای MP3 داخلی (پیش‌فرض: `heeeeyyyyy.mp3`) و زنگوله متحرک، و ابزار کپی زمان مخصوص برنامه‌نویسان.

---

</div>

<div dir="rtl">

## 📌 فهرست مطالب
- [معرفی و ویژگی‌های کلیدی](#-معرفی-و-ویژگیهای-کلیدی)
- [ساختار پوشه‌ها و معماری پروژه](#-ساختار-پوشهها-و-معماری-پروژه)
- [نحوه دانلود و اجرای سریع (بدون نیاز به پایتون)](#-نحوه-دانلود-و-اجرای-سریع-بدون-نیاز-به-پایتون)
- [راهنمای کامل امکانات و نحوه کارکرد](#-راهنمای-کامل-امکانات-و-نحوه-کارکرد)
  - [۱. دکمه قفل هوشمند (🔒/🔓) و عبوردهی کلیک (Click-Through)](#۱-دکمه-قفل-هوشمند--و-عبوردهی-کلیک-click-through)
  - [۲. کنترل لایه نمایش (Z-Index)](#۲-کنترل-لایه-نمایش-z-index)
  - [۳. تقویم ماهانه بازشونده (Extend) و مناسبت‌ها](#۳-تقویم-ماهانه-بازشونده-extend-و-مناسبتها)
  - [۴. سیستم رویداد، یادآور و آلارم (⏰) با زنگوله متحرک و صداهای MP3](#۴-سیستم-رویداد-یادآور-و-آلارم--با-زنگوله-متحرک-و-صداهای-mp3)
  - [۵. ابزار کپی زمان برای برنامه‌نویسان (📋)](#۵-ابزار-کپی-زمان-برای-برنامهنویسان-)
  - [۶. پنجره تنظیمات ظاهری، رنگ، سایز و فونت (⚙)](#۶-پنجره-تنظیمات-ظاهری-رنگ-سایز-و-فونت-)
- [🆕 امکانات نسخه دوم (v2.0.0 — Dev & AI Suite)](#-امکانات-نسخه-دوم-v200--dev--ai-suite)
- [اجرا از طریق سورس کد پایتون](#-اجرا-از-طریق-سورس-کد-پایتون)
- [نحوه ساخت مجدد فایل اجرایی (`.exe`)](#-نحوه-ساخت-مجدد-فایل-اجرایی-exe)
- [طراح و توسعه‌دهنده (حق ناشر)](#-طراح-و-توسعهدهنده-حق-ناشر)

---

## ✨ معرفی و ویژگی‌های کلیدی

| ویژگی | توضیحات |
| :--- | :--- |
| 🕒 **ساعت دقیق تهران (`UTC+03:30`)** | محاسبه مستقل از منطقه زمانی ویندوز؛ نمایش همیشه دقیق ساعت رسمی ایران |
| 📅 **تقویم شمسی و قمری ۱۰۰٪ آفلاین** | دیتابیس کامل مناسبت‌های ملی، باستانی و مذهبی ایران و تشخیص روزهای تعطیل رسمی بدون نیاز به اینترنت |
| 🖋 **خط دور مشکی (`Black Outline`) و ابعاد پویا** | رسم حاشیه مشکی دور تمام اعداد و نوشته‌ها برای خوانایی کامل روی هر والپیپر + محاسبه خودکار ابعاد برای جلوگیری از بریده شدن متون در فونت‌های بسیار کوچک یا بزرگ |
| 🔒 **قفل هوشمند و عبوردهی کلیک (`Click-Through`)** | قرارگیری دکمه قفل در بالا-چپ داخل ویجت؛ در حالت قفل، کلیک ماوس در ناحیه مشترک مستقیماً روی اپلیکیشن زیرین کار می‌کند و **فقط خود دکمه قفل** قابل کلیک است |
| ⏰ **سیستم آلارم و یادآور حرفه‌ای + تقویم چندانتخابی** | انتخاب روزها به شکل **تقویم گرافیکی چندانتخابی (Multi-Select)**، هر روز یا روزهای خاص هفته، با ۶ صدای MP3 داخلی (پیش‌فرض `heeeeyyyyy.mp3`)، زنگوله متحرک مرکز صفحه و **حذف خودکار آلارم‌های منقضی‌شده** |
| 📋 **ابزار کپی ۱۰ فرمت زمان API + تولیدکننده GUID** | کپی سریع **۱۰ فرمت پرکاربرد تاریخ و ساعت برای پر کردن APIها** (تاریخ و ساعت با هم، تاریخ جدا، ساعت جدا، تایم‌استمپ) + **تولید و کپی فوری `GUID / UUID v4`** |
| 🔤 **فونت پیش‌فرض وزیر (`Vazir`) + فونت‌های باندل‌شده** | تنظیم پیش‌فرض روی فونت **وزیر (`Vazir`)** به همراه فونت‌های **بی‌یکان پلاس (`B Yekan+`)** و **ایرانیان سنس (`A Iranian Sans`)** در داخل فایل `.exe` بدون نیاز به نصب فونت در ویندوز |
| ✨ **افکت Hover و راهنمای شناور (Tooltip)** | تغییر رنگ زیبا و نمایش توضیحات شناور هنگام نگه داشتن ماوس روی تمام آیکون‌های ویجت و تقویم |
| ⭐ **جایگزینی کامل ساعت و تاریخ ویندوز در تسک‌بار (با یک تیک)** | پوشاندن ۱۰۰٪ مات ساعت و تاریخ پیش‌فرض انگلیسی ویندوز با ساعت دقیق تهران و تاریخ شمسی در گوشه تسک‌بار؛ با کلیک چپ تقویم بالای ساعت باز می‌شود، با راست‌کلیک تنظیمات در دسترس است و ماوس روی آن Hover و Tooltip دارد + امکان مخفی کردن ویجت دسکتاپ و نمایش اختصاصی در تسک‌بار |
| 👻 **اجرا در پس‌زمینه (فقط در Hidden Icons)** | بدون اشغال هیچ فضایی در نوار وظیفه (`Taskbar`) یا `Alt+Tab`؛ حضور تمیز در بخش `System Tray` کنار ساعت ویندوز با قابلیت اجرا در `Startup` |

---

## 📂 ساختار پوشه‌ها و معماری پروژه

پروژه با ساختار ماژولار و استاندارد زیر سازماندهی شده است و فایل اجرایی مستقل در پوشه مجزای `release/` قرار دارد:

<div dir="ltr">

```text
persian-clock-widget/
├── assets/                        # منابع گرافیکی، فونت‌ها و فایل‌های صوتی باندل‌شده
│   ├── fonts/                     # فونت‌های فارسی داخلی (بدون نیاز به نصب در ویندوز)
│   │   ├── BYekan+ Bold.ttf
│   │   ├── Iranian Sans.ttf
│   │   └── Vazir-Medium.ttf
│   ├── icons/                     # آیکون‌های اختصاصی برنامه و System Tray
│   │   ├── app_icon.ico
│   │   └── app_icon.png
│   └── sounds/                    # فایل‌های صوتی MP3 آلارم (پیش‌فرض: heeeeyyyyy.mp3)
│       ├── heeeeyyyyy.mp3         # ⭐ صدای پیش‌فرض آلارم
│       ├── alarm.mp3
│       ├── axel.mp3
│       ├── liilililililililii.mp3
│       ├── morning_glory.mp3
│       └── peter_axel_f.mp3
├── data/                          # محل ذخیره تنظیمات کاربر، آلارم‌ها و مناسبت‌های شخصی
│   ├── alarms.json                # لیست رویدادها و آلارم‌های ثبت‌شده توسط کاربر
│   ├── config.json                # تنظیمات ظاهری، مکان، رنگ‌ها و فونت
│   └── custom_occasions.json      # فایل افزودن مناسبت‌های شخصی آفلاین
├── release/                       # 📦 خروجی‌های نهایی ویندوز و لینوکس
│   ├── windows/                   # نسخه مستقل ویندوز (Portable EXE & ZIP)
│   │   ├── v1/                    # نسخه ۱ (کلاسیک + پایش IP و تاریخچه ۳ روزه)
│   │   ├── v2/                    # نسخه ۲ (همه امکانات v1 + ابزارهای Dev & AI)
│   │   ├── PersianClockWidget.exe
│   │   └── PersianClockWidget.zip
│   └── linux/                     # بسته‌های نصبی و پرتابل لینوکس
│       ├── persian-clock-widget_1.0.0_all.deb
│       ├── PersianClockWidget-Linux-Installer.sh
│       ├── PersianClockWidget-linux-portable.tar.gz
│       └── INSTALL-LINUX.txt      # نوت دستورات سریع نصب در لینوکس
├── scripts/                       # اسکریپت ساخت فایل اجرایی
│   └── build_exe.bat              # اسکریپت کامپایل خودکار به فایل exe در پوشه release/
├── src/                           # کدهای منبع اصلی برنامه (Source Code)
│   ├── __init__.py
│   ├── alarm_manager.py           # مدیریت آلارم‌ها، پخش صدا و پاپ‌آپ زنگوله متحرک
│   ├── calendar_data.py           # مبدل تقویم شمسی/قمری/میلادی و دیتابیس مناسبت‌ها
│   ├── dev_ai_hub.py              # پنجره ۵ تب ابزارهای هوشمند برنامه‌نویسی و AI (نسخه ۲)
│   ├── dev_tools.py               # دستیار Cron، مبدل Timestamp/JWT، ULID/NanoID و جلسات
│   ├── icon_generator.py          # تولیدکننده آیکون برداری ساعت و تقویم فارسی
│   ├── ip_monitor.py              # پایش زنده IP/شهر، قفل روی شهر و تاریخچه ۳ روزه
│   ├── local_api.py               # سرور محلی HTTP REST و MCP JSON-RPC برای ابزارهای AI
│   ├── scheduler_actions.py       # اجرای خودکار اکشن سر ساعت (URL / Webhook / Command)
│   ├── widget.py                  # رابط گرافیکی اصلی ویجت، تقویم ماهانه و پنجره تنظیمات
│   ├── taskbar_clock.py           # ساعت روی تسک‌بار و آیکون برنامه در تسک‌بار
│   └── win_utils.py               # توابع Win32 API (Z-Index، Click-Through، فونت، صدا و Tray)
├── .gitignore
├── LICENSE                        # مجوز انتشار MIT (® Shayan Bamyar)
├── main.py                        # نقطه ورود اصلی برنامه (Main Entry Point)
├── requirements.txt               # وابستگی‌های پایتون برای توسعه
└── README.md                      # مستندات کامل پروژه
```

</div>

---

## 🚀 راهنمای نصب و دانلود (Windows / Linux / macOS)

### ⚡ جدول دانلود سریع بر اساس سیستم‌عامل و معماری

| سیستم‌عامل | معماری / توزیع | فایل پیشنهادی (`v2.0.0`) | نسخه کلاسیک (`v1.0.3`) |
| :--- | :--- | :--- | :--- |
| 🪟 **Windows** | **64-bit (`win-x64`)** | [`PersianClockWidget-v2.0.0-win-x64.exe`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-win-x64.exe) / [`.zip`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-win-x64.zip) | [`PersianClockWidget-v1.0.3-win-x64.exe`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v1.0.3/PersianClockWidget-v1.0.3-win-x64.exe) / [`.zip`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v1.0.3/PersianClockWidget-v1.0.3-win-x64.zip) |
| 🪟 **Windows** | **32-bit (`win-x86`)** | نصب با `npm` یا سورس پایتون ۳۲ بیتی | `npm install -g persian-clock-widget@1.0.3` |
| 🐧 **Linux** | **Debian / Ubuntu / Mint** | [`PersianClockWidget-v2.0.0-linux-all.deb`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-linux-all.deb) | [`PersianClockWidget-v1.0.3-linux-all.deb`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v1.0.3/PersianClockWidget-v1.0.3-linux-all.deb) |
| 🐧 **Linux** | **همه توزیع‌ها (`.sh` / `.tar.gz`)** | [`linux-installer.sh`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-linux-installer.sh) / [`linux-portable.tar.gz`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-linux-portable.tar.gz) | [`linux-installer.sh`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v1.0.3/PersianClockWidget-v1.0.3-linux-installer.sh) / [`linux-portable.tar.gz`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v1.0.3/PersianClockWidget-v1.0.3-linux-portable.tar.gz) |
| 🍎 **macOS** | **Apple Silicon & Intel** | [`PersianClockWidget-v2.0.0-macos-universal.tar.gz`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-macos-universal.tar.gz) | [`PersianClockWidget-v1.0.3-macos-universal.tar.gz`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v1.0.3/PersianClockWidget-v1.0.3-macos-universal.tar.gz) |

---

### 🪟 ۱. ویندوز (Windows 10 / 11 — 64-bit و 32-bit)

#### روش الف — اجرای مستقیم فایل `.exe` (پیشنهادی برای `win-x64`)
- دانلود فایل اجرایی پرتابل: **[`PersianClockWidget-v2.0.0-win-x64.exe`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-win-x64.exe)**
- دانلود فایل فشرده: **[`PersianClockWidget-v2.0.0-win-x64.zip`](https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-win-x64.zip)**
- بدون نیاز به نصب پایتون یا فونت؛ تمام منابع در داخل فایل `.exe` قرار دارند.

#### روش ب — نصب نسخه کلاسیک (`v1.0.3`) از طریق `npm` (مناسب `win-x64` و `win-x86`)
> 💻 **محیط اجرا: Windows PowerShell (یا Windows Terminal)**
<div dir="ltr">

```powershell
# نصب سراسری نسخه کلاسیک v1.0.3
npm install -g persian-clock-widget@1.0.3

# اجرای ویجت
persian-clock
```

</div>

> 💻 **محیط اجرا: Windows PowerShell — اجرای سریع بدون نصب دائمی (`npx`)**
<div dir="ltr">

```powershell
npx persian-clock-widget@1.0.3
```

</div>

---

### 🐧 ۲. لینوکس (Ubuntu / Debian / Mint / Fedora / Arch / Manjaro)

> 🐧 **محیط اجرا: Linux Terminal (Bash) — نصب پیش‌نیازهای سیستم (فقط بار اول)**
<div dir="ltr">

```bash
# Ubuntu / Debian / Linux Mint:
sudo apt update && sudo apt install -y python3 python3-tk mpv

# Fedora:
sudo dnf install -y python3 python3-tkinter mpv

# Arch / Manjaro:
sudo pacman -S python tk mpv
```

</div>

#### روش الف — نصب با بسته `.deb` (Ubuntu / Debian / Mint / Pop!_OS)
> 🐧 **محیط اجرا: Linux Terminal (Bash)**
<div dir="ltr">

```bash
wget https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-linux-all.deb
sudo apt install ./PersianClockWidget-v2.0.0-linux-all.deb
persian-clock-widget
```

</div>

#### روش ب — نصب تک‌فایلی خودکار روی همه توزیع‌ها (`.sh`)
> 🐧 **محیط اجرا: Linux Terminal (Bash)**
<div dir="ltr">

```bash
wget https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-linux-installer.sh
chmod +x PersianClockWidget-v2.0.0-linux-installer.sh
bash PersianClockWidget-v2.0.0-linux-installer.sh
```

</div>

#### روش ج — اجرای پرتابل بدون نصب (`.tar.gz`)
> 🐧 **محیط اجرا: Linux Terminal (Bash)**
<div dir="ltr">

```bash
wget https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-linux-portable.tar.gz
tar -xzf PersianClockWidget-v2.0.0-linux-portable.tar.gz
cd persian-clock-widget
./scripts/run_linux.sh
```

</div>

#### روش د — نصب نسخه کلاسیک (`v1.0.3`) با `npm` در لینوکس
> 🐧 **محیط اجرا: Linux Terminal (Bash)**
<div dir="ltr">

```bash
npm install -g persian-clock-widget@1.0.3
persian-clock
```

</div>

---

### 🍎 ۳. مک (macOS — Apple Silicon & Intel)

> 🍎 **محیط اجرا: macOS Terminal (Zsh / Bash) — نصب پیش‌نیاز Tkinter**
<div dir="ltr">

```bash
brew install python python-tk
```

</div>

#### روش الف — بسته آماده پرتابل مک (`macos-universal`)
> 🍎 **محیط اجرا: macOS Terminal (Zsh / Bash)**
<div dir="ltr">

```bash
curl -LO https://github.com/ShayanBamyar97/persian-clock-widget/releases/download/v2.0.0/PersianClockWidget-v2.0.0-macos-universal.tar.gz
tar -xzf PersianClockWidget-v2.0.0-macos-universal.tar.gz
cd persian-clock-widget
./PersianClockWidget.command
```

</div>

#### روش ب — نصب نسخه کلاسیک (`v1.0.3`) با `npm` در مک
> 🍎 **محیط اجرا: macOS Terminal (Zsh / Bash)**
<div dir="ltr">

```bash
npm install -g persian-clock-widget@1.0.3
persian-clock
```

</div>

> **نکته:** قابلیت «جایگزینی ساعت در تسک‌بار» مخصوص سیستم‌عامل ویندوز است؛ سایر امکانات (ویجت دسکتاپ، تقویم شمسی، آلارم‌ها، پایش و قفل IP، ابزارهای برنامه‌نویسان و سرویس هوش مصنوعی) در لینوکس و macOS هم کار می‌کنند.

---

### 📦 ۴. نسخه‌ها و Releases موجود

| نسخه | شاخه (`Branch`) | روش نصب / دانلود | توضیحات |
| :--- | :--- | :--- | :--- |
| **[v2.0.0](https://github.com/ShayanBamyar97/persian-clock-widget/releases/tag/v2.0.0)** | `feat/v2-dev-ai-suite` | [GitHub Release v2.0.0](https://github.com/ShayanBamyar97/persian-clock-widget/releases/tag/v2.0.0) | **Dev & AI Suite**: پومودورو، Cron/Timer، تولید داده تست، REST API و MCP سرور برای هوش مصنوعی |
| **[v1.0.3](https://github.com/ShayanBamyar97/persian-clock-widget/releases/tag/v1.0.3)** | [`main`](https://github.com/ShayanBamyar97/persian-clock-widget/tree/main) | `npm i -g persian-clock-widget@1.0.3` / [GitHub Release v1.0.3](https://github.com/ShayanBamyar97/persian-clock-widget/releases/tag/v1.0.3) | نسخه کلاسیک سبک + مانیتورینگ و قفل شهر/IP، تاریخچه ۳ روزه و اصلاح کامل تسک‌بار |

---

## 📖 راهنمای کامل امکانات و نحوه کارکرد

### ۱. دکمه قفل هوشمند (`🔒` / `🔓`)، حذف فضای خالی و چسبیدن به لبه مانیتور
در گوشه **بالا-سمت چپ در داخل ویجت** یک دکمه کوچک قفل قرار دارد:
- **حالت باز (`🔓` آبی)**:
  - می‌توانید ویجت را با کشیدن ماوس (**Drag & Drop**) در هر نقطه‌ای از مانیتور قرار دهید (مختصات به صورت خودکار ذخیره می‌شود).
  - نوار دکمه‌های `◂ تقویم`، `📋`، `GUID`، `⏰`، `⚙` و `🗕` (مینیمایز) در کنار دکمه قفل نمایش داده می‌شوند و قابل کلیک هستند.
- **حالت قفل و فیکس هوشمند (`🔒` طلایی)**:
  - با کلیک روی `🔓`، تقویم باز خودکار بسته می‌شود و نوار دکمه‌ها مخفی می‌گردد.
  - **حذف کامل فضای خالی و حداقل اندازه (Ultra-Minimal)**: ابعاد ویجت دقیقاً به اندازه متن ساعت و تاریخ کوچک شده و نوشته فوتر (`® Shayan Bamyar`) در حالت قفل محو می‌شود تا کمترین فضای ممکن را از صفحه اشغال کند.
  - **چسبیدن خودکار به لبه صفحه (Smart Edge Docking)**: اگر ویجت در نیمه راست صفحه باشد کاملاً به **لبه راست مانیتور** می‌چسبد و اگر در نیمه چپ باشد به **لبه چپ مانیتور** متصل می‌شود.
  - پنجره ویجت با ویژگی سیستمی `WS_EX_TRANSPARENT | WS_EX_LAYERED` ویندوز کاملاً **Click-Through (عبوردهنده کلیک)** می‌شود؛ یعنی کلیک در ناحیه مشترک مستقیماً روی اپلیکیشن زیرین کار می‌کند و هیچ جای ویجت به‌جز **خود دکمه کوچک قفل (`🔒`)** کلیک را جذب نمی‌کند.
  - هر زمان که دوباره روی دکمه `🔒` کلیک کنید، ویجت از حالت قفل خارج شده و نوار ابزار در دسترس قرار می‌گیرد.

### ۱.۱. قابلیت مینیمایز (مخفی کردن از صفحه؛ فقط در تسک‌بار و Hidden Icons)
- با کلیک روی دکمه **`🗕`** (یا از منوی راست‌کلیک)، پنجره ویجت از روی صفحه دسکتاپ محو شده و **فقط در تسک‌بار و بخش Hidden Icons (کنار ساعت ویندوز)** قرار می‌گیرد.
- با یک کلیک روی آیکون برنامه در تسک‌بار یا آیکون Tray، ویجت بلافاصله به مکان قبلی خود بازمی‌گردد.

### ۲. کنترل لایه نمایش (`Z-Index`)
از طریق پنجره تنظیمات (`⚙`) یا منوی راست‌کلیک می‌توانید نحوه قرارگیری ویجت نسبت به سایر پنجره‌ها را تعیین کنید:
- **همیشه روی تمام برنامه‌ها (`Topmost` - پیش‌فرض)**: حتی اگر برنامه جدیدی باز شود، ویجت روی آن باقی می‌ماند.
- **چسبیده به والپیپر دسکتاپ (`Desktop`)**: ویجت مانند گجت‌های کلاسیک ویندوز روی تصویر زمینه دسکتاپ و در پشت پنجره‌های باز قرار می‌گیرد.

### ۳. تقویم ماهانه بازشونده (`Extend`) و مناسبت‌ها
- با کلیک روی دکمه **`◂ تقویم`** (یا دابل‌کلیک روی ویجت)، پنل کامل تقویم ماهانه در کنار ویجت باز می‌شود.
- با دکمه‌های `‹` و `›` می‌توانید ماه‌های سال را ورق بزنید و با دکمه **`امروز`** به تاریخ جاری برگردید.
- روزهای تعطیل رسمی و جمعه‌ها با **رنگ قرمز مرجانی** و روزهای دارای مناسبت یا یادآور شخصی با **نقطه رنگی (`•`)** در زیر عدد روز مشخص می‌شوند.
- با **کلیک روی هر روز از ماه**، مناسبت‌های شمسی و قمری و آلارم‌های ثبت‌شده آن روز در پایین تقویم نمایش داده می‌شوند.
- اگر روزی هیچ مناسبتی نداشته باشد، هیچ عبارت اضافه‌ای (مانند «بدون مناسبت») نوشته نمی‌شود و فضای ویجت به شکل مینیمال جمع می‌شود.
- **🎂 ثبت مناسبت‌های شخصی و تولد دوستان + آلارم خودکار ۱ روز قبل**:
  - با کلیک روی دکمه **`🎂 + مناسبت / تولد`** در پایین تقویم (یا از منوی راست‌کلیک)، می‌توانید روز تولد دوستان، سالگردها یا تعطیلات شخصی را برای هر روز و ماه شمسی روی تقویم ثبت کنید.
  - با فعال ماندن تیک **«ثبت خودکار آلارم یادآور ۱ روز قبل (تکرار سالانه)»**، برنامه به‌صورت خودکار هر سال یک روز قبل از تاریخ تولد/مناسبت (حتی اگر روز اول ماه باشد، در روز آخر ماه قبل) در ساعت دلخواه شما آلارم می‌گذارد تا هرگز تولدی را فراموش نکنید.

### ۴. سیستم رویداد، یادآور و آلارم (`⏰`) با تقویم چندانتخابی و حذف خودکار
با کلیک روی دکمه **`⏰`** در بالای ویجت (یا دکمه **`⏰ + ثبت آلارم / رویداد`** در پایین تقویم ماهانه)، پنجره مدیریت آلارم‌ها باز می‌شود:
- **تعیین متن و ساعت**: می‌توانید عنوان/متن دلخواه و ساعت و دقیقه دقیق (به وقت تهران) را وارد کنید.
- **۳ حالت زمان‌بندی و تکرار**:
  1. **انتخاب از روی تقویم (تک‌روز یا چند روز خاص - Multi-Select)**: یک تقویم شمسی گرافیکی و تعاملی باز می‌شود که می‌توانید با کلیک روی روزهای مختلف (حتی در ماه‌های مختلف)، **یک یا چند روز خاص** را هم‌زمان انتخاب یا از انتخاب خارج کنید.
  2. **هر روز (`Daily`)**: تکرار روزانه در ساعت مشخص‌شده.
  3. **روزهای خاص هفته (`Weekly`)**: انتخاب یک یا چند روز از هفته (مثلاً **هر دوشنبه** و **هر چهارشنبه**).
- **انتخاب صدای آلارم MP3 و تست زنده**:
  - شامل ۶ صدای آلارم داخلی (`heeeeyyyyy.mp3` به عنوان پیش‌فرض، `alarm.mp3`، `axel.mp3`، `liilililililililii.mp3`، `morning_glory.mp3` و `peter_axel_f.mp3`).
  - با دکمه **`▶ تست صدا`** می‌توانید صدای انتخابی را قبل از ذخیره گوش دهید و با دکمه **`🔔 پیش‌نمایش زنگوله + صدا`** کل هشدار را شبیه‌سازی کنید.
- **پاپ‌آپ مرکز مانیتور در زمان سررسید و حذف خودکار پس از انقضا**:
  - در لحظه رسیدن زمان آلارم، یک پنجره دارک در **مرکز مانیتور** باز می‌شود که یک **زنگوله طلایی متحرک در حال تکان خوردن و زنگ زدن** به همراه ساعت و متن اختصاصی شما را نمایش می‌دهد و صدای انتخابی را پخش می‌کند.
  - دارای دکمه **`✓ متوجه شدم (قطع آلارم)`** و دکمه **`💤 ۵ دقیقه دیگر (Snooze)`**.
  - **پاک‌سازی هوشمند**: وقتی زمان یک آلارم تاریخ‌محور بگذرد و به تاخیر (`Snooze`) نیفتد، آن تاریخ (یا کل آلارم در صورت تمام شدن تمام روزهای انتخاب‌شده) **به‌طور خودکار از لیست پاک می‌شود** تا لیست آلارم‌ها همیشه تمیز بماند.
- **مدیریت کامل لیست**: امکان **ویرایش (`✏️`)**، **حذف (`🗑`)** و **فعال/غیرفعال‌سازی** هر یک از آلارم‌ها.

### ۵. ابزار کپی زمان برای برنامه‌نویسان (`📋`) + تولیدکننده `GUID`
برنامه‌نویسان می‌توانند با کلیک روی آیکون **`📋`** (که با فاصله استاندارد از ویجت باز می‌شود تا روی ساعت را نپوشاند)، **۱۰ فرمت پرکاربرد تاریخ و ساعت برای پر کردن APIها** و همچنین **`GUID (UUID v4)`** را در لحظه کپی کنند:
- **بخش ۱: تاریخ و ساعت با هم (`Date & Time - API / ISO / DB`)**:
  1. `ISO-8601 UTC (ms)`: فرمت استاندارد جهانی با میلی‌ثانیه (`2026-11-11T06:15:12.340Z`)
  2. `ISO-8601 Tehran (ms)`: فرمت استاندارد تهران با آفست (`2026-11-11T09:45:12.340+03:30`)
  3. `SQL / API DateTime`: فرمت دیتابیس و کوئری با میلی‌ثانیه (`2026-11-11 09:45:12.340`)
  4. `Jalali DateTime (ms)`: تاریخ و ساعت شمسی کامل با میلی‌ثانیه (`1405/08/20 09:45:12.340`)
- **بخش ۲: فقط تاریخ جدا (`Date Only`)**:
  5. `Date Only (Gregorian)`: فقط تاریخ میلادی (`2026-11-11`)
  6. `Date Only (Jalali)`: فقط تاریخ شمسی (`1405/08/20`)
- **بخش ۳: فقط ساعت جدا (`Time Only`)**:
  7. `Time Only + ms (Tehran)`: فقط ساعت دقیق به همراه میلی‌ثانیه (`09:45:12.340`)
  8. `Time Only (HH:MM:SS)`: فقط ساعت استاندارد بدون میلی‌ثانیه (`09:45:12`)
- **بخش ۴: تایم‌استمپ عددی (`Epoch / Unix Timestamp`)**:
  9. `Unix Timestamp (ms)`: زمان یونیکس بر حسب میلی‌ثانیه (`1794377712340`)
  10. `Unix Timestamp (sec)`: زمان یونیکس بر حسب ثانیه (`1794377712`)
- **بخش ۵: رندر و کپی `GUID / UUID v4`**:
  - `🎲 Render & Copy GUID (v4)`: تولید و کپی GUID استاندارد حروف کوچک (`xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx`)
  - `🎲 Render GUID (UPPERCASE)`: تولید و کپی GUID با حروف بزرگ
  - `🎲 Render GUID (No Hyphens)`: تولید و کپی GUID ۳۲ کاراکتری بدون خط تیره
  - `🎲 Copy Empty GUID`: کپی GUID صفر (`00000000-0000-0000-0000-000000000000`)
- **کپی یکجای `JSON`**: گزینه `📦 Copy All as JSON Object` برای کپی تمام مقادیر بالا در یک آبجکت JSON.

### ۶. پنجره تنظیمات ظاهری، رنگ، سایز و فونت (`⚙`)
با کلیک روی دکمه **`⚙`** (یا از منوی راست‌کلیک در System Tray)، پنجره تنظیمات باز می‌شود و تغییرات را **به صورت زنده (Live Preview)** اعمال می‌کند:
- **با پس‌زمینه یا بدون پس‌زمینه**: امکان حذف کامل کادر کارت (نمایش فقط نوشته‌ها با خط دور مشکی روی تصویر زمینه) یا تنظیم درصد شفافیت (`Opacity` از ۲۵٪ تا ۱۰۰٪).
- **انتخاب رنگ مجزا برای تمام بخش‌ها**: انتخابگر رنگ (`Color Picker`) برای **رنگ ساعت**، **رنگ تاریخ شمسی**، **رنگ مناسبت‌ها**، **رنگ روزهای تعطیل**، **رنگ کارت پس‌زمینه** و **رنگ دکمه‌ها**.
- **تنظیم اندازه کلی ویجت و فونت‌ها**:
  - اسلایدر **بزرگ‌نمایی کلی ویجت** (`70%` تا `170%`).
  - انتخاب **نوع فونت متون و ساعت** (شامل فونت‌های فارسی باندل‌شده `Vazir`، `B Yekan+` و `A Iranian Sans` + فونت‌های سیستم).
  - تنظیم جداگانه **سایز فونت ساعت**، **سایز فونت تاریخ** و **سایز فونت مناسبت**.
- **نمایش و جایگزینی در تسک‌بار ویندوز** (قابل فعال‌سازی با یک تیک؛ پیش‌فرض خاموش):
  - **⭐ جایگزینی کامل ساعت و تاریخ ویندوز در تسک‌بار (`Replace Windows Clock`)**:
    - **با یک تیک**، پنجره ساعت و تاریخ شمسی مستقیماً **به داخل نوار تسک‌بار ویندوز (`Shell_TrayWnd`) متصل (`SetParent`)** می‌شود تا کاملاً جزئی از تسک‌بار باشد (نه پنجره شناور روی برنامه‌های تمام‌صفحه).
    - **تشخیص خودکار رنگ تسک‌بار (`Auto Theme & Pixel Sample`)**: رنگ پس‌زمینه تسک‌بار ویندوز ۱۰/۱۱ (تم تیره یا روشن) را به‌طور خودکار تشخیص داده و با آن یکدست می‌شود؛ در ویندوز ۱۰ ساعت کلاسیک `TrayClockWClass` را مخفی می‌کند و در ویندوز ۱۱ گزینه مستقیم **حذف ساعت و تاریخ انگلیسی از تسک‌بار (`HideSystrayDateTimeValueName`)** نیز در تنظیمات تعبیه شده است.
    - در دو خط منظم و زیبا: خط بالا ساعت دقیق تهران با خط دور مشکی (`Outlined`) و خط پایین تاریخ شمسی استاندارد (همراه با رنگ تفکیک‌شده روزهای تعطیل) را نمایش می‌دهد.
    - **کلیک چپ**: باز و بسته کردن تقویم ماهانه شمسی دقیقاً بالای ساعت گوشه تسک‌بار (مشابه کلیک روی ساعت ویندوز).
    - **کلیک راست**: دسترسی فوری به منوی کامل برنامه و تنظیمات.
    - **افکت Hover و Tooltip شناور**: با نگه داشتن ماوس، پس‌زمینه هایلایت شده و تولتیپ شناور شامل نام روز، تاریخ کامل و مناسبت روز بالای ساعت نمایش داده می‌شود.
    - **جابه‌جایی دستی (Drag)**: با کلیک و کشیدن ماوس به چپ یا راست، موقعیت قرارگیری روی ساعت ویندوز تنظیم شده و فاصله به صورت خودکار در `config.json` ذخیره می‌شود.
    - **👁️ مخفی کردن ویجت دسکتاپ (اختیاری)**: اگر مایل باشید هیچ ویجت شناوری روی دسکتاپ نباشد و تنها ساعت تسک‌بار نمایش داده شود، با تیک زدن گزینه *«مخفی کردن ویجت دسکتاپ هنگام فعال بودن جایگزینی»*، ویجت شناور مخفی شده و تقویم مستقیماً از روی ساعت تسک‌بار باز و بسته می‌شود.
    - **دکمه‌های بازنشانی و انتخاب رنگ**: دکمه بازنشانی موقعیت به گوشه مانیتور و انتخابگر رنگ پس‌زمینه برای هماهنگی با هر رنگ و پوسته‌ای از ویندوز.
  - **🕒 ساعت و تاریخ شمسی شناور روی تسک‌بار (حالت شفاف)**: ساعت تهران و تاریخ شمسی را با پس‌زمینه شفاف در کنار ساعت ویندوز نمایش می‌دهد.
  - **📌 آیکون برنامه در تسک‌بار**: یک دکمه مجزا در تسک‌بار اضافه می‌کند که با کلیک، تقویم ماهانه باز و بسته می‌شود.

---

## 🆕 امکانات نسخه دوم (v2.0.0 — Dev & AI Suite)

در شاخه `feat/v2-dev-ai-suite` و پوشه `release/windows/v2/`، علاوه بر حفظ تمام امکانات نسخه ۱ (شامل چیدمان فشرده دو ردیفه، ساعت تسک‌بار با فونت بومی ویندوز در مانیتور اول و دوم، تک‌نمونه‌ای بودن برنامه، و پایش IP و تاریخچه ۳ روزه تغییر شهر/IP)، ۵ قابلیت جدید برای برنامه‌نویسان و اتصال به ابزارهای هوش مصنوعی اضافه شده است (با کلیک روی دکمه **`⚡ AI`** در ویجت باز می‌شود):

1. **🤖 اتصال مستقیم به ابزارهای AI (Local HTTP REST + MCP Server)**:
   - اجرای سرور محلی امن روی `http://127.0.0.1:17845` (قابل روشن/خاموش کردن).
   - پشتیبانی از پروتکل **MCP (JSON-RPC 2.0)** در مسیر `POST /mcp` با ۵ ابزار آماده برای Claude، Antigravity، Cursor و Codex:
     - `get_persian_datetime` (ساعت و تاریخ شمسی، UTC، تعطیلی و مناسبت)
     - `get_ip_location_status` (IP، شهر، قفل لوکیشن و تاریخچه ۳ روزه)
     - `list_alarms` (لیست یادآورها و رویدادها)
     - `schedule_reminder` (ثبت یادآور با `in_minutes` یا تاریخ شمسی + اکشن اختیاری)
     - `start_pomodoro_timer` (شروع تایمر پومودورو روی ویجت)
   - همراه با اندپوینت‌های REST (`GET /health`، `GET /now`، `GET /ip`، `GET /alarms`، `POST /alarms`، `POST /timer`) و دکمه **کپی یک‌کلیکی کانفیگ MCP**.

2. **⚙ دستیار Cron و پیش‌بینی اجرا (Cron Expression Builder)**:
   - تحلیل عبارات ۵ بخشی Cron و نمایش توضیح خوانای فارسی.
   - محاسبه ۵ زمان اجرای بعدی هم به وقت **تهران (شمسی)** و هم **UTC** به همراه قالب‌های آماده.

3. **🕒 مبدل Timestamp / ISO / شمسی + دیکدر آفلاین JWT + تولید ID**:
   - تبدیل دوطرفه Unix Timestamp (ثانیه و میلی‌ثانیه)، ISO-8601 و تاریخ شمسی.
   - بررسی **کاملاً آفلاین** توکن `JWT` و نمایش زمان صدور (`iat`) و انقضا (`exp`) به تاریخ شمسی و زمان باقی‌مانده.
   - تولید و کپی فوری `GUID`، `ULID` و `NanoID`.

4. **🌍 برنامه‌ریز ساعت جلسات تیمی (Meeting Time Planner)**:
   - تبدیل هم‌زمان ساعت تهران به `UTC`، لندن، برلین/آمستردام، دبی، نیویورک و تورنتو + کپی متن آماده دعوت‌نامه جلسه.

5. **⏱ تایمر پومودورو (Deep Work) + زمان‌بند اکشن سر ساعت**:
   - تایمر ۲۵/۵/۴۵ دقیقه‌ای با شمارنده معکوس زنده روی ویجت و آلارم پایان زمان.
   - امکان اتصال اکشن‌های خودکار **باز کردن لینک (`url`)**، **ارسال `POST Webhook`** یا **اجرای دستور سیستم (`command`)** به رویدادها و آلارم‌ها.

6. **🌐 پایش زنده IP، قفل روی شهر و تاریخچه ۳ روزه**:
   - نمایش شهر، کشور و IP عمومی روی ویجت، امکان **قفل روی شهر فعلی** یا **IP فعلی** با آلارم فوری صوتی/تصویری در صورت تغییر لوکیشن، و نگهداری تاریخچه تغییرات ۳ روز گذشته.

---

## 💻 اجرا از طریق سورس کد پایتون

اگر مایل به اجرای مستقیم از روی سورس کد یا توسعه پروژه هستید:

<div dir="ltr">

```powershell
# ۱. نصب پیش‌نیازها
pip install -r requirements.txt

# ۲. اجرای برنامه (با کنسول یا بدون کنسول)
pythonw main.py
```

</div>

---

## 🛠 نحوه ساخت مجدد فایل اجرایی (`.exe` و خروجی لینوکس)

### ویندوز:
برای کامپایل مجدد پروژه و ساخت فایل تک‌فایلی `PersianClockWidget.exe` در پوشه `release/` (به همراه تعبیه خودکار فونت‌ها، آیکون و صداهای MP3)، کافی است اسکریپت زیر را اجرا کنید:

<div dir="ltr">

```bat
scripts\build_exe.bat
```

</div>
پس از اتمام، فایل اجرایی مستقل در مسیر `release\PersianClockWidget.exe` آماده خواهد بود.

### لینوکس (`Linux`):
> 🐧 **راهنمای کامل و اختصاصی نصب و اجرا در لینوکس:** [README-LINUX.md](README-LINUX.md)

دو فایل نصبی آماده برای لینوکس در پوشه `release/linux/` قرار دارد:
1. **فایل نصبی دبیان / اوبونتو (`.deb`)**: [persian-clock-widget_1.0.0_all.deb](release/linux/persian-clock-widget_1.0.0_all.deb)
   ```bash
   sudo apt install ./persian-clock-widget_1.0.0_all.deb
   ```
   *(پیش‌نیاز `python3-tk`، فونت‌های وزیر، آیکون و میانبر منوی برنامه‌ها را خودکار نصب می‌کند).*
2. **نصب‌کننده تک‌فایلی تمام توزیع‌ها (`.sh`)**: [PersianClockWidget-Linux-Installer.sh](release/linux/PersianClockWidget-Linux-Installer.sh)
   ```bash
   bash PersianClockWidget-Linux-Installer.sh
   ```
   *(فایل‌ها، فونت‌ها، میانبر منوی برنامه‌ها و اجرای خودکار با شروع لینوکس را نصب و بلافاصله اجرا می‌کند).*
3. **نوت دستورات سریع نصب**: [INSTALL-LINUX.txt](release/linux/INSTALL-LINUX.txt)

گزینه **«اجرا خودکار با شروع ویندوز / لینوکس (Startup)»** هم در پنجره تنظیمات (`⚙`) و هم در منوی راست‌کلیک در دسترس است.

---

## 👨‍💻 طراح و توسعه‌دهنده (حق ناشر)

طراحی، معماری و توسعه توسط **شایان بامیار (`® Shayan Bamyar`)** انجام شده است.  
منتشر شده تحت مجوز [MIT License](LICENSE).

</div>
